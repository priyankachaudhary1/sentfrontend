require('dotenv').config();

const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
const session = require('express-session');
const csurf = require('csurf');
const hpp = require('hpp');
const DB = require('./databaseConn/connection');
const USER = require('./model/usermodel');
const userroute = require('./route/userroute');
const orderroute = require('./route/orderroute');
const tagroute = require('./route/tagroute');
const authroute = require('./route/authroute');
const urlroute = require('./route/urlroute');
const iproute = require('./route/iproute');

const globalErrorHandlerController = require('./controller/errorcontroller');
const AppError = require('./reusable/appError');
const urlModel = require('./model/urlmodel');

const app = express();


// const limiter = rateLimit({
//     windowMs: 2*60*1000,
//     max: 3,
//     message: 'Too many requests',
//     handler: (req, res, next) => {
//         return next(new AppError(429, 'To many request from this ip.'))
//     }
// })

// Security middlewares
app.use(helmet());
app.use(hpp());
app.use(cors());
app.use(express.json());
// app.use(limiter);

// Session management
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: { secure: true }
  }));
  
//   // CSRF protection
// app.use(csurf({ cookie: true }));

// app.use((req, res, next) => {
//     if(req.headers.cookie){
//         console.log('It consists of cookies');
//         console.log(req.headers.cookie);
//     }
//     else{
//         console.log('There is no cookie coming');
//     }
//     next();
// })

DB.Database_Connection().then(() => {
    DB.sequelize.sync().then(() => {
        console.log('Database Connection Synced');
    })
    .catch((err) => {
        console.log('Database Connection Sync Failed: ', err);
    })
})
.catch((err) => console.log('Database Connection Failed: ', err.message))


app.use('/healthcheck', (req, res) => {
    res.status(200).json({
        status: 'success',
        message: 'You are successfully landing at home page'
    })
})

app.use('/api/users', userroute);
app.use('/api/orders', orderroute);
app.use('/api/tags', tagroute);
app.use('/api/auth', authroute);
app.use('/api/url', urlroute);
app.use('/api/ips', iproute);


app.all('*', (req, res, next) => {
    next(new AppError(404, `Cannot find ${req.originalUrl} on server. Use valid`));
})

app.use(globalErrorHandlerController);

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});