const tagModel = require('../model/tagmodel');
const { sequelize } = require('../databaseConn/connection');

const seedTags = async () => {
    try {
        // Authenticate the connection
        await sequelize.authenticate();
        console.log('Connection has been established successfully.');

        // Disable foreign key checks
        await sequelize.query('SET FOREIGN_KEY_CHECKS = 0');

        // Drop and recreate the table
        await sequelize.sync({ force: true });
        console.log('Database synchronized successfully.');

        // Enable foreign key checks
        await sequelize.query('SET FOREIGN_KEY_CHECKS = 1');

        // Dummy data to insert
        const tags = [
            { tag_identifier: '$TERESAJONES101k', tag_name: 'JohnDoe', tagdetails: 'This tag can be used for identifying John Doe in the system.', tag_status: 'RUNNING' },
            { tag_identifier: '$janesmithtag33', tag_name: 'JaneSmith', tagdetails: 'This tag can be used for identifying Jane Smith in the system.', tag_status: 'CLOSED' },
            { tag_identifier: '$mikejohnsontag44', tag_name: 'MikeJohnson', tagdetails: 'This tag can be used for identifying Mike Johnson in the system.', tag_status: 'RUNNING' },
            { tag_identifier: '$emilydavistag66', tag_name: 'EmilyDavis', tagdetails: 'This tag can be used for identifying Emily Davis in the system.', tag_status: 'CLOSED' },
            { tag_identifier: '$chrisbrowntag62', tag_name: 'ChrisBrown', tagdetails: 'This tag can be used for identifying Chris Brown in the system.', tag_status: 'RUNNING' },
            { tag_identifier: '$patriciamillertag21', tag_name: 'PatriciaMiller', tagdetails: 'This tag can be used for identifying Patricia Miller in the system.', tag_status: 'CLOSED' },
        ];

        // Insert dummy data
        await tagModel.bulkCreate(tags);
        console.log('Dummy data inserted successfully');
        process.exit();
    } catch (error) {
        console.error('Error inserting dummy data:', error);
        process.exit(1);
    }
};

seedTags();