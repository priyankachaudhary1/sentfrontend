class AppError extends Error {
    constructor(httpStatusCode, message) {
        super(message);
        this.httpStatusCode = httpStatusCode;
        this.errorStatus = `${httpStatusCode}`.startsWith('4') ? 'fail' : 'error';
        this.isOperational = true; // Indicates if the error is operational (trusted) or a programming error

        // Captures the stack trace, excluding the constructor call from it
        Error.captureStackTrace(this, this.constructor);
    }
}

module.exports = AppError;