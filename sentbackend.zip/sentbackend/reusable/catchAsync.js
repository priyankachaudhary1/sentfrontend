/**
 * A higher-order function to catch errors in asynchronous route handlers.
 * @param {Function} asyncFn - The asynchronous function to be wrapped.
 * @returns {Function} A function that executes the asyncFn and catches any errors.
 */
module.exports = asyncFn => {
    return (req, res, next) => {
        asyncFn(req, res, next).catch(err => next(err));
    };
};