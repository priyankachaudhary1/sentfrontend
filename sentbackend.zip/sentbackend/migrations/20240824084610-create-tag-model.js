'use strict';

module.exports = {
  up: async (queryInterface, Sequelize) => {
    await queryInterface.createTable('TagModels', {
      tag_id: {
        type: Sequelize.INTEGER,
        autoIncrement: true,
        primaryKey: true
      },
      tag_identifier: {
        type: Sequelize.STRING,
        unique: true,
        allowNull: false
      },
      tag_name: {
        type: Sequelize.STRING,
        allowNull: false
      },
      tagdetails: {
        type: Sequelize.STRING,
        allowNull: false
      },
      tag_status: {
        type: Sequelize.ENUM('CLOSED', 'RUNNING'),
        allowNull: false,
        defaultValue: 'RUNNING'
      }
    });
  },

  down: async (queryInterface, Sequelize) => {
    await queryInterface.dropTable('TagModels');
  }
};