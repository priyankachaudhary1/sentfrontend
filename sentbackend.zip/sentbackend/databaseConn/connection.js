const { Sequelize } = require('sequelize');

const connection_credentials = {
    username: 'root',
    host: 'localhost',
    database: 'websiteDB',
    password: '',
    dialect: 'mysql'
}

const sequelize = new Sequelize(connection_credentials.database,
    connection_credentials.username,
    connection_credentials.password,
    {
        host: connection_credentials.host,
        dialect: connection_credentials.dialect
    }
)

const Database_Connection = async () => {
    return await sequelize.authenticate();
}

module.exports = {sequelize, Database_Connection};