const router = require('express').Router();
const userController = require('./../controller/usercontroller');

router.route('/').post(userController.createuser);
router.route('/check').post(userController.getuser);
router.route('/getallusers').get(userController.getAllUser);
router.get('/users/:id', userController.getUserById);
router.put('/users/:id', userController.updateUserById);
router.delete('/users/:id', userController.deleteUserById);

module.exports = router;