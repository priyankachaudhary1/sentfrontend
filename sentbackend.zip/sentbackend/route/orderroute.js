const router = require('express').Router();
const ordercontroller = require('./../controller/ordercontroller');

router.route('/').post(ordercontroller.createOrder);
router.get('/', ordercontroller.getAllOrders);
router.get('/:id', ordercontroller.getOrderById);
router.post('/', ordercontroller.createOrder);
router.put('/:id', ordercontroller.updateOrder);
router.delete('/:id', ordercontroller.deleteOrder);

module.exports = router;