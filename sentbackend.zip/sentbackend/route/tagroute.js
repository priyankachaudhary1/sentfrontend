const router = require('express').Router();
const tagController = require('./../controller/tagController');

// Generate URLs from tag identifiers
router.route('/generate-urls').get(tagController.generateTagUrls);

// Create a new tag
router.route('/').post(tagController.createTag);

// Get all tags
router.route('/').get(tagController.getAllTags);

// Get a specific tag by ID
router.route('/:id').get(tagController.getTagById);

// Update a specific tag by ID
router.route('/:id').patch(tagController.updateTagById);

// Delete a specific tag by ID
router.route('/:id').delete(tagController.deleteTagById);

module.exports = router;