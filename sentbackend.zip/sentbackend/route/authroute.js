const router = require('express').Router();
const authController = require('./../controller/authcontroller');

router.route('/signup').post(authController.createAdmin);
router.route('/login').post(authController.login);

module.exports = router;