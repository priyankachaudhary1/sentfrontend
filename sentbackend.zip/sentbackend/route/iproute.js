const express = require('express');
const router = express.Router();
const ipController = require('../controller/ipcontroller');

router.get('/', ipController.getAllIPs);
router.get('/:id', ipController.getIPById);
router.post('/', ipController.createIP);
router.put('/:id', ipController.updateIP);
router.delete('/:id', ipController.deleteIP);
router.post('/check', ipController.checkIP);

module.exports = router;