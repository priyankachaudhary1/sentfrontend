const router = require('express').Router();
const urlController = require('../controller/urlcontroller');

// Route to check URL token
router.post('/check-url-token', urlController.checkUrlToken);

// Route to create a new URL
router.post('/', urlController.createUrl);

// Route to get all URLs
router.get('/', urlController.getAllUrls);

// Route to get a URL by ID
router.get('/:id', urlController.getUrlById);

// Route to update a URL by ID
router.put('/:id', urlController.updateUrlById);

// Route to delete a URL by ID
router.delete('/:id', urlController.deleteUrlById);

module.exports = router;