const {DataTypes} = require('sequelize');
const {sequelize} = require('./../databaseConn/connection');
const bcrypt = require('bcryptjs');

const authModel = sequelize.define('AuthModel', {
    id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    username: {
        type: DataTypes.STRING,
        allowNull: false
    },

    password: {
        type: DataTypes.STRING,
        allowNull: false
    }
},
{
    hooks: {
        beforeCreate: async(admin) => {
            const hashedpassword = await bcrypt.hash(admin.password, 12);
            admin.password = hashedpassword;
        }
    }
})

module.exports = authModel;