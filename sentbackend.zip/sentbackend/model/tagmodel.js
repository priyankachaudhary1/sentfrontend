const { DataTypes } = require('sequelize');
const { sequelize } = require('./../databaseConn/connection');

const tagModel = sequelize.define('TagModel', {
    tag_id: {
        type: DataTypes.INTEGER,
        autoIncrement: true, 
        primaryKey: true
    },

    tag_identifier: {
        type: DataTypes.STRING,
        unique: true,
        allowNull: false
    },

    tag_name: {
        type: DataTypes.STRING,
        allowNull: false
    },

    tagdetails: {
        type: DataTypes.STRING,
        allowNull: false
    },
    tag_status: {
        type: DataTypes.ENUM('CLOSED', 'RUNNING'),
        allowNull: false,
        defaultValue: 'RUNNING'
    }
},
{
    timestamps: false
});

module.exports = tagModel;