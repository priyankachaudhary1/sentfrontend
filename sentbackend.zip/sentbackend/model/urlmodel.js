const { DataTypes } = require('sequelize');
const { sequelize } = require('./../databaseConn/connection');

const urlModel = sequelize.define('UrlModel', {
    url_id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    url_token: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    }
}, 
{
    timestamps: false
});

module.exports = urlModel;