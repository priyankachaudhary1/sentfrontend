const { DataTypes } = require('sequelize');
const { sequelize } = require('./../databaseConn/connection');

const IPModel = sequelize.define('IPModel', {
    ip_id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },
    ip_address: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },
    ip_status: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true
    }
}, {
    timestamps: false
});

module.exports = IPModel;