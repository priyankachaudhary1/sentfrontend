const {DataTypes} = require('sequelize');
const {sequelize} = require('./../databaseConn/connection');

const botModel = sequelize.define('botModel', {
    order_id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    
    order_no: {
        type: DataTypes.STRING,
        allowNull: false,
        defaultValue: 'test'
    },

    user_name: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    sender: {
        type: DataTypes.STRING,
        allowNull: false,
    }, 

    reciever: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    tag_identifier: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    identifier: {
        type: DataTypes.STRING,
        allowNull: false
    },

    source: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    payment_status: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    amount: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    url: {
        type: DataTypes.STRING,
        allowNull: false
    },

    ip:{
        type: DataTypes.STRING,
        allowNull: false
    },

    createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
    },
}, {
    timestamps: false
})

module.exports = botModel;