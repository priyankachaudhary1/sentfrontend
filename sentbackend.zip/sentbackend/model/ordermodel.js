const { DataTypes } = require('sequelize');
const { sequelize } = require('./../databaseConn/connection');
const userModel = require('./usermodel');
const tagModel = require('./tagmodel');
const urlModel = require('./urlmodel');

const orderModel = sequelize.define('OrderModel', {

    order_id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true
    },
    
    order_no: {
        type: DataTypes.STRING,
        allowNull: false,
        defaultValue: 'test'
    },

    user_name: {
        type: DataTypes.STRING,
        allowNull: false,
        references: {
            model: userModel,
            key: 'user_name'
        },
        onDelete: 'CASCADE',
        onUpdate: 'CASCADE'
    },

    sender: {
        type: DataTypes.STRING,
        allowNull: false,
    }, 

    reciever: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    identifier:{
        type: DataTypes.STRING,
        allowNull: false
    },

    source: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    payment_status: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    amount: {
        type: DataTypes.STRING,
        allowNull: false,
    },

    url_token: {
        type: DataTypes.STRING, 
        allowNull: false,
    },

    ip:{
        type: DataTypes.STRING,
        allowNull: false
    },

    createdAt: {
        type: DataTypes.DATE,
        allowNull: false,
        defaultValue: DataTypes.NOW
    },
},

{
    timestamps: false
}

)

userModel.hasOne(orderModel, {foreignKey: 'user_name', sourceKey: 'user_name'});
orderModel.belongsTo(userModel, {foreignKey: 'user_name', targetKey: 'user_name'});

tagModel.hasOne(orderModel, {foreignKey: 'tag_identifier', sourceKey: 'tag_identifier' });
orderModel.belongsTo(userModel, {foreignKey: 'tag_identifier', sourceKey: 'tag_identifier'});

module.exports = orderModel;