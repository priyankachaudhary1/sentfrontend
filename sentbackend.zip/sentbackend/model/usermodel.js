const {DataTypes} = require('sequelize');
const {sequelize} = require('./../databaseConn/connection');
const { Json } = require('sequelize/lib/utils');

const userModel = sequelize.define('UserModel', {
    user_id: {
        type: DataTypes.INTEGER,
        autoIncrement: true,
        primaryKey: true,
    },

    user_name: {
        type: DataTypes.STRING,
        allowNull: false,
        unique: true
    },

    user_ipaddress: {
        type: DataTypes.STRING,
        allowNull: false,
        defaultValue: '127.0.0.1'
    },

    user_status: {
        type: DataTypes.BOOLEAN,
        allowNull: false,
        defaultValue: true
    }
},
{
    timestamps: false
}
)

module.exports = userModel;