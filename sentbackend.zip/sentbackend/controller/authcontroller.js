const AppError = require('../reusable/appError');
const catchAsync = require('../reusable/catchAsync');
const AUTH = require('./../model/authmodel');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { promisify } = require('util');
const crypto = require('crypto');

/**
 * Signs a JWT token with the given user ID.
 * @param {string} id - The user ID.
 * @returns {string} The signed JWT token.
 */
const signToken = (id) => jwt.sign({ id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES
});

/**
 * Creates and sends a JWT token as a cookie and JSON response.
 * @param {number} statusCode - The HTTP status code.
 * @param {Object} user - The user object.
 * @param {Object} res - The response object.
 */
const createSendToken = (statusCode, user, res) => {
    const token = signToken(user.user_id);
    res.cookie('verify', token, {
        expires: new Date(Date.now() + 30 * 60 * 60 * 1000),
        httpOnly: true,
        path: '/'
    });
    user.password = undefined;

    res.status(statusCode).json({
        status: 'success',
        token,
        data: user
    });
};

/**
 * Creates a new admin user.
 */
exports.createAdmin = catchAsync(async (req, res, next) => {
    const newAdmin = await AUTH.create(req.body);
    createSendToken(200, newAdmin, res);
});

/**
 * Logs in a user.
 */
exports.login = catchAsync(async (req, res, next) => {
    const { username, password } = req.body;

    if (!username || !password) {
        return next(new AppError('Please provide both username and password', 400));
    }

    if (username.includes(' ') || username.includes('--') || password.includes(' ') || password.includes('--')) {
        return next(new AppError(402, 'Invalid credentials'));
    }

    const user = await AUTH.findOne({ where: { username } });

    if (!user || !(await bcrypt.compare(password, user.password))) {
        return next(new AppError(401, 'Invalid username or password'));
    }

    createSendToken(200, user, res);
});

/**
 * Protects routes by verifying JWT token.
 */
exports.protect = catchAsync(async (req, res, next) => {
    let token;

    if (req.headers.cookie) {
        token = req.headers.cookie.split('=')[1];
    }

    if (!token) {
        return next(new AppError(404, 'You are not logged in. Please login first'));
    }

    const decoded = await promisify(jwt.verify)(token, process.env.JWT_SECRET);
    console.log(decoded.id);

    next();
});

/**
 * Sends a password reset email to the user.
 */
exports.forgotPassword = catchAsync(async (req, res, next) => {
    const { email } = req.body;
    const user = await AUTH.findOne({ where: { email } });

    if (!user) {
        return next(new AppError('There is no user with that email address', 404));
    }

    const resetToken = user.createPasswordResetToken();
    await user.save({ validateBeforeSave: false });

    const resetURL = `${req.protocol}://${req.get('host')}/api/v1/users/resetPassword/${resetToken}`;

    const message = `Forgot your password? Submit a PATCH request with your new password and passwordConfirm to: ${resetURL}.\nIf you didn't forget your password, please ignore this email!`;

    try {
        await sendEmail({
            email: user.email,
            subject: 'Your password reset token (valid for 10 minutes)',
            message
        });

        res.status(200).json({
            status: 'success',
            message: 'Token sent to email!'
        });
    } catch (err) {
        user.passwordResetToken = undefined;
        user.passwordResetExpires = undefined;
        await user.save({ validateBeforeSave: false });

        return next(new AppError('There was an error sending the email. Try again later!', 500));
    }
});

/**
 * Resets the user's password.
 */
exports.resetPassword = catchAsync(async (req, res, next) => {
    const hashedToken = crypto.createHash('sha256').update(req.params.token).digest('hex');

    const user = await AUTH.findOne({
        where: {
            passwordResetToken: hashedToken,
            passwordResetExpires: { [Op.gt]: Date.now() }
        }
    });

    if (!user) {
        return next(new AppError('Token is invalid or has expired', 400));
    }

    user.password = req.body.password;
    user.passwordResetToken = undefined;
    user.passwordResetExpires = undefined;
    await user.save();

    createSendToken(200, user, res);
});

/**
 * Updates the user's password.
 */
exports.updatePassword = catchAsync(async (req, res, next) => {
    const user = await AUTH.findByPk(req.user.id);

    if (!(await bcrypt.compare(req.body.passwordCurrent, user.password))) {
        return next(new AppError('Your current password is wrong', 401));
    }

    user.password = req.body.password;
    await user.save();

    createSendToken(200, user, res);
});

/**
 * Refreshes the JWT token.
 */
exports.refreshToken = catchAsync(async (req, res, next) => {
    let token;

    if (req.headers.cookie) {
        token = req.headers.cookie.split('=')[1];
    }

    if (!token) {
        return next(new AppError(404, 'You are not logged in. Please login first'));
    }

    const decoded = await promisify(jwt.verify)(token, process.env.JWT_SECRET);

    const user = await AUTH.findByPk(decoded.id);

    if (!user) {
        return next(new AppError('The user belonging to this token no longer exists', 401));
    }

    createSendToken(200, user, res);
});


/**
 * Logs out a user by clearing the JWT token from cookies.
 */
exports.logout = (req, res) => {
    res.cookie('verify', 'loggedout', {
        expires: new Date(Date.now() + 10 * 1000),
        httpOnly: true,
        path: '/'
    });
    res.status(200).json({ status: 'success' });
};

/**
 * Middleware to restrict access based on user roles.
 * @param {...string} roles - The roles that are allowed to access the route.
 */
exports.restrictTo = (...roles) => {
    return (req, res, next) => {
        if (!roles.includes(req.user.role)) {
            return next(new AppError('You do not have permission to perform this action', 403));
        }
        next();
    };
};