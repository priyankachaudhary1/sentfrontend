const { sequelize } = require('../databaseConn/connection');
const catchAsync = require('./../reusable/catchAsync');
const AppError = require('../reusable/appError');
const { validateAndCreateURL } = require('../services/urlService');
const { validateUserAndIP } = require('../services/userService');
const { callAPIAndValidateData } = require('../services/apiService');
const orderModel = require('../model/ordermodel');

exports.createOrder = catchAsync(async (req, res, next) => {
    const { url, user_name, ip } = req.body;
    console.log(url, user_name, ip);
    const transaction = await sequelize.transaction();

    try {
        await validateUserAndIP(user_name, ip);
       const valiadatedURL =  await validateAndCreateURL(url);

        const data = await callAPIAndValidateData(url);

        const orderData = {
            user_name: user_name,
            sender: data['From'],
            reciever: data['To'],
            tag_identifier: data['Receiver_Tag'],
            identifier: data['Identifier'],
            source: data['Source'],
            payment_status: data['Status'],
            amount: parseFloat(data['Amount'].replace('$', '')),
            url_token: valiadatedURL.url_token,
            ip: ip
        };

        const newOrder = await orderModel.create(orderData, { transaction });

        await transaction.commit();
        return res.status(200).json({ message: "Order created successfully", order: newOrder });
    } catch (error) {
        await transaction.rollback();
        console.log(error);
        next(error);
    }
});

exports.getAllOrders = async (req, res) => {
    try {
        const orders = await orderModel.findAll();
        res.status(200).json({
            status: 'success',
            data: orders
        });
    } catch (error) {
        res.status(500).json({
            status: 'error',
            message: error.message
        });
    }
};

exports.getOrderById = async (req, res) => {
    try {
        const order = await orderModel.findByPk(req.params.id);
        if (!order) {
            return res.status(404).json({
                status: 'error',
                message: 'Order not found'
            });
        }
        res.status(200).json({
            status: 'success',
            data: order
        });
    } catch (error) {
        res.status(500).json({
            status: 'error',
            message: error.message
        });
    }
};

exports.updateOrder = async (req, res) => {
    try {
        const order = await orderModel.findByPk(req.params.id);
        if (!order) {
            return res.status(404).json({
                status: 'error',
                message: 'Order not found'
            });
        }
        const updatedOrder = await order.update(req.body);
        res.status(200).json({
            status: 'success',
            data: updatedOrder
        });
    } catch (error) {
        res.status(500).json({
            status: 'error',
            message: error.message
        });
    }
};

exports.deleteOrder = async (req, res) => {
    try {
        const order = await orderModel.findByPk(req.params.id);
        if (!order) {
            return res.status(404).json({
                status: 'error',
                message: 'Order not found'
            });
        }
        await order.destroy();
        res.status(204).json({
            status: 'success',
            data: null
        });
    } catch (error) {
        res.status(500).json({
            status: 'error',
            message: error.message
        });
    }
};