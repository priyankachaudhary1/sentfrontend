
const AppError = require('../reusable/appError');
const USER = require('./../model/usermodel');
const catchAsync = require('./../reusable/catchAsync');

exports.createuser = catchAsync(async (req, res) => {

    if(req.body.user_name.includes(' ')) return next(new AppError('Invalid username consists space'))

    const createUser = await USER.create(req.body);
    console.log('User created successfully');
    res.status(200).json({
        status: 'success',
        data: createUser
    })
})

exports.getuser = catchAsync(async (req, res, next) => {
    const { user_name, user_ipaddress } = req.body;

    if (!user_name || !user_ipaddress || user_name.includes(' ') || user_name.includes("--")) {
        return next(new AppError(402, 'Invalid username'));
    }

    const getuser = await USER.findOne({ where: { user_name } });

    if (!getuser) {
        return next(new AppError(401, 'User not found'));
    }

    if (!getuser.dataValues.user_status) {
        return next(new AppError(403, 'User is inactive'));
    }

    if (getuser.dataValues.user_ipaddress !== user_ipaddress) {
        const updateuserip = await getuser.update({ user_ipaddress });
        return res.status(200).json({
            status: 'success',
            data: updateuserip
        });
    }

    res.status(200).json({
        status: 'success',
        data: getuser
    });
});

exports.getAllUser = catchAsync(async (req, res, next) => {
    const getAllUser = await USER.findAll();

    res.status(200).json({
        status: 'success',
        data: getAllUser
    })
})


exports.getUserById = catchAsync(async (req, res, next) => {
    const user = await USER.findByPk(req.params.id);
    if (user) {
        res.status(200).json(user);
    } else {
        return next(new AppError(404, 'User not found'));
    }
});

exports.updateUserById = catchAsync(async (req, res, next) => {
    const [updated] = await USER.update(req.body, {
        where: { user_id: req.params.id }
    });
    if (updated) {
        const updatedUser = await USER.findByPk(req.params.id);
        res.status(200).json(updatedUser);
    } else {
        return next(new AppError(404, 'User not found'));
    }
});

exports.deleteUserById = catchAsync(async (req, res, next) => {
    const deleted = await USER.destroy({
        where: { user_id: req.params.id }
    });
    if (deleted) {
        res.status(204).json();
    } else {
        return next(new AppError(404, 'User not found'));
    }
});