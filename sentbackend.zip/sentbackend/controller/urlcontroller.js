const axios = require('axios');
const urlModel = require('../model/urlmodel');

exports.checkUrlToken = async (req, res) => {
    try {
        const { url, url_token } = req.body;

        const response = await axios.get(url);

        if (response.status !== 200) {
            throw new Error('Invalid URL');
        }

        // Find the URL record
        const urlRecord = await urlModel.findOne({ where: { url_token } });

        if (urlRecord) {
            throw new Error('Token already used.');
        }

        // Check if the urlModel is empty
        const urlCount = await urlModel.count();
        if (urlCount === 0) {
            return res.status(200).json({ message: 'Valid URL' });
        }
        
        // If no conditions are met, return a default response
        res.status(404).json({ message: 'URL token not found and URL model is not empty.' });
    } catch (error) {
        res.status(500).json({ error: 'Internal Server Error', details: error.message });
    }
};

// Controller method to create a new URL
exports.createUrl = async (req, res) => {
    try {
        const { url, url_token } = req.body;
        const newUrl = await urlModel.create({ url, url_token });
        res.status(201).json(newUrl);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Controller method to get all URLs
exports.getAllUrls = async (req, res) => {
    try {
        const urls = await urlModel.findAll();
        res.status(200).json(urls);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Controller method to get a URL by ID
exports.getUrlById = async (req, res) => {
    try {
        const url = await urlModel.findByPk(req.params.id);
        if (url) {
            res.status(200).json(url);
        } else {
            res.status(404).json({ error: 'URL not found' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Controller method to update a URL by ID
exports.updateUrlById = async (req, res) => {
    try {
        const { url, url_token } = req.body;
        const [updated] = await urlModel.update({ url, url_token }, {
            where: { url_id: req.params.id }
        });
        if (updated) {
            const updatedUrl = await urlModel.findByPk(req.params.id);
            res.status(200).json(updatedUrl);
        } else {
            res.status(404).json({ error: 'URL not found' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};

// Controller method to delete a URL by ID
exports.deleteUrlById = async (req, res) => {
    try {
        const deleted = await urlModel.destroy({
            where: { url_id: req.params.id }
        });
        if (deleted) {
            res.status(204).json();
        } else {
            res.status(404).json({ error: 'URL not found' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};