const tagModel = require('./../model/tagmodel');

// Create a new tag
exports.createTag = async (req, res) => {
    try {
        const { tag_identifier, tag_name, tagdetails } = req.body;
        const newTag = await tagModel.create({ tag_identifier, tag_name, tagdetails });
        res.status(201).json({ message: 'Tag created successfully', data: newTag });
    } catch (error) {
        res.status(500).json({ message: 'Error creating tag', error: error.message });
    }
};

// Get all tags
exports.getAllTags = async (req, res) => {
    try {
        const tags = await tagModel.findAll();
        res.status(200).json({ message: 'All tags retrieved successfully', data: tags });
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving tags', error: error.message });
    }
};

// Get a specific tag by ID
exports.getTagById = async (req, res) => {
    try {
        const { id } = req.params;
        const tag = await tagModel.findByPk(id);
        if (!tag) {
            return res.status(404).json({ message: `Tag ${id} not found` });
        }
        res.status(200).json({ message: `Tag ${id} retrieved successfully`, data: tag });
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving tag', error: error.message });
    }
};

// Update a specific tag by ID
exports.updateTagById = async (req, res) => {
    try {
        const { id } = req.params;
        const { tag_identifier, tag_name, tagdetails } = req.body;
        const tag = await tagModel.findByPk(id);
        if (!tag) {
            return res.status(404).json({ message: `Tag ${id} not found` });
        }
        await tag.update({ tag_identifier, tag_name, tagdetails });
        res.status(200).json({ message: `Tag ${id} updated successfully`, data: tag });
    } catch (error) {
        res.status(500).json({ message: 'Error updating tag', error: error.message });
    }
};

// Delete a specific tag by ID
exports.deleteTagById = async (req, res) => {
    try {
        const { id } = req.params;
        const tag = await tagModel.findByPk(id);
        if (!tag) {
            return res.status(404).json({ message: `Tag ${id} not found` });
        }
        await tag.destroy();
        res.status(204).json({ message: `Tag ${id} deleted successfully` });
    } catch (error) {
        res.status(500).json({ message: 'Error deleting tag', error: error.message });
    }
};


// Generate URLs from tag identifiers
exports.generateTagUrls = async (req, res) => {
    try {
        const tags = await tagModel.findAll();
        const baseUrl = 'https://cash.app/qr/';
        const response = tags
            .filter(tag => tag.tag_status !== 'CLOSED')
            .map(tag => ({
                url: `${baseUrl}${tag.tag_identifier}`,
                tag_identifier: tag.tag_identifier,
                name: tag.tag_name
            }));
        res.status(200).json({ message: 'URLs generated successfully', data: response });
    } catch (error) {
        res.status(500).json({ message: 'Error generating URLs', error: error.message });
    }
};
