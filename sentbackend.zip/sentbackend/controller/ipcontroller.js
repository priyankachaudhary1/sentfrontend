const IPModel = require('../model/ipmodel');

// Get all IPs
exports.getAllIPs = async (req, res) => {
    try {
        const ips = await IPModel.findAll();
        res.status(200).json({ message: 'IPs retrieved successfully', data: ips });
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving IPs', error: error.message });
    }
};

// Get IP by ID
exports.getIPById = async (req, res) => {
    try {
        const ip = await IPModel.findByPk(req.params.id);
        if (!ip) {
            return res.status(404).json({ message: 'IP not found' });
        }
        res.status(200).json({ message: 'IP retrieved successfully', data: ip });
    } catch (error) {
        res.status(500).json({ message: 'Error retrieving IP', error: error.message });
    }
};

// Create a new IP
exports.createIP = async (req, res) => {
    try {
        const newIP = await IPModel.create(req.body);
        res.status(201).json({ message: 'IP created successfully', data: newIP });
    } catch (error) {
        res.status(500).json({ message: 'Error creating IP', error: error.message });
    }
};

// Update an IP
exports.updateIP = async (req, res) => {
    try {
        const ip = await IPModel.findByPk(req.params.id);
        if (!ip) {
            return res.status(404).json({ message: 'IP not found' });
        }
        await ip.update(req.body);
        res.status(200).json({ message: 'IP updated successfully', data: ip });
    } catch (error) {
        res.status(500).json({ message: 'Error updating IP', error: error.message });
    }
};

// Delete an IP
exports.deleteIP = async (req, res) => {
    try {
        const ip = await IPModel.findByPk(req.params.id);
        if (!ip) {
            return res.status(404).json({ message: 'IP not found' });
        }
        await ip.destroy();
        res.status(200).json({ message: 'IP deleted successfully' });
    } catch (error) {
        res.status(500).json({ message: 'Error deleting IP', error: error.message });
    }
};

// Check if IP exists
exports.checkIP = async (req, res) => {
    try {
        const { ip_address } = req.body;
        const ip = await IPModel.findOne({ where: { ip_address } });
        if (ip) {
            return res.status(403).json({ message: 'Your IP is Blocked' });
        }
        res.status(200).json({ message: 'OK' });
    } catch (error) {
        res.status(500).json({ message: 'Error checking IP', error: error.message });
    }
};