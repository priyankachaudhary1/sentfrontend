const URL = require('./../model/urlmodel');
const validator = require('validator');
const AppError = require('../reusable/appError');

exports.validateAndCreateURL = async (url) => {
    if (!validator.isURL(url) || !url.startsWith('https://') || !url.includes('cash.app/payments')) {
        throw new AppError('Invalid URL format', 400);
    }

    // Extract the token using regex
    const tokenMatch = url.match(/cash\.app\/payments\/([a-zA-Z0-9]+)\//);
    if (!tokenMatch) {
        throw new AppError('Invalid URL format: Token not found', 400);
    }
    const url_token = tokenMatch[1];

    // Save the token to the urlModel
    try {
        await URL.create({ url_token });
    } catch (error) {
        throw new AppError('Error saving URL token to the database', 500);
    }

    return { message: 'The URL is valid and token saved.', url_token: url_token };
};