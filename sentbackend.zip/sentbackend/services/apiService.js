const axios = require('axios');
const moment = require('moment');
const orderModel = require('./../model/ordermodel');
const tagModel = require('../model/tagmodel');
const AppError = require('../reusable/appError');

exports.callAPIAndValidateData = async (url) => {
    const response = await axios.post('http://localhost:5555/api/scrape', {
        url: url
    }, {
        headers: {
            'Content-Type': 'application/json'
        }
    });

    const data = response.data;

    if (data['Status'] !== 'Completed') {
        throw new AppError('Status is not valid', 400);
    } 

    if (data['Source'] !== 'Cash') {
        throw new AppError('Source is not valid', 400);
    }

    if (data['Identifier']) {
        const existIdentifier = await orderModel.findAll({ where: { identifier: data['Identifier'] } });
        if (existIdentifier.length > 0) {
            throw new AppError('Not a unique transaction', 400);
        }
    }

    // const currentDate = moment();
    // const transactionDate = moment(data['Date'], 'MMM DD, YYYY [at] h:mm A');
    // if (!transactionDate.isValid() || Math.abs(currentDate.diff(transactionDate, 'days')) > 4) {
    //     throw new AppError('Date is not within 3 days of the current date', 400);
    // }

    const tagRecord = await tagModel.findOne({ where: { tag_identifier: data['Receiver_Tag'] } });

    if (!tagRecord) {
        throw new AppError(`The tag doesn't exist.`, 400);
    }

    const amount = parseFloat(data['Amount'].replace('$', ''));
    if (isNaN(amount) || amount <= 5) {
        throw new AppError('Amount should be greater than 5', 400);
    }

    return data;
};