const userModel = require('../model/usermodel');
const IPModel = require('../model/ipmodel');
const AppError = require('../reusable/appError');

exports.validateUserAndIP = async (user_name, ip) => {
    const user = await userModel.findOne({ where: { user_name } });
    if (!user) {
        throw new AppError('User not found', 404);
    }

    const ipRecord = await IPModel.findOne({ where: { ip_address: ip } });
    if (ipRecord) {
        throw new AppError('You are not allowed to perform this action from your current IP.', 403);
    }

    return user;
};