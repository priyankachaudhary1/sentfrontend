import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Userpanel from './pages/user-panel'
import Payment from './pages/payment'
import PrivateRoute from './routes/private-routes';
import ErrorPage from './pages/error-page';
import "./index.css";

function App() {

  return (
    <div>
        <BrowserRouter>
          <Routes>
            <Route path='/' element={<Userpanel />} />
            <Route element={<PrivateRoute />}>
              <Route path='/payment' element={<Payment />} exact />
            </Route>
            <Route path='*' element={<ErrorPage />} />
          </Routes>
        </BrowserRouter>
    </div>
  )

}

export default App
