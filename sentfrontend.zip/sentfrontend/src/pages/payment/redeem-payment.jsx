import { useForm } from 'react-hook-form';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { CardContent } from "@/components/ui/card";

const RedeemPayment = () => {
    const { register, handleSubmit, formState: { errors }, reset } = useForm();

    const onSubmit = (data) => {
        console.log('Redeem Code:', data.redeemCode);
        reset();
    };

    return (
                <CardContent className="flex flex-col items-center">
                    <form onSubmit={handleSubmit(onSubmit)} className="w-full">
                        <Input 
                            className="mb-4 w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500" 
                            type='text' 
                            placeholder='Enter redeem code' 
                            {...register('redeemCode', { required: 'Redeem code is required' })} 
                        />
                        {errors.redeemCode && <p className="text-red-500">{errors.redeemCode.message}</p>}
                        <Button 
                            className="w-full py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition duration-300" 
                            type="submit"
                        >
                            Redeem
                        </Button>
                    </form>
                </CardContent>
    );
};

export default RedeemPayment;