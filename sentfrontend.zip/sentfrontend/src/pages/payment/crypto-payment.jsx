const CryptoPayment = () => {
    return (
        <div> Crypto Integrated Soon.</div>
    );
};

export default CryptoPayment;