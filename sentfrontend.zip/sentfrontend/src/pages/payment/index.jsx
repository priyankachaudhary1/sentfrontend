import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import CryptoPayment from './crypto-payment';
import RedeemPayment from './redeem-payment';
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import qr from "../../assets/qr-30.png";
import crypto from "../../assets/crypto-50.png";
import redeem from "../../assets/redeem-50.png";
import { Label } from "@/components/ui/label"
import {
    Card,
    CardContent,
    CardTitle,
} from "@/components/ui/card"
import QRCarousel from "@/components/qr-carousel";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { toast } from 'react-hot-toast';
import { DollarSign } from 'lucide-react';

const Payment = () => {
    const [view, setView] = useState('scan');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isTokenUsed, setIsTokenUsed] = useState(false);
    const [orderSuccess, setOrderSuccess] = useState(false);
    const { register, handleSubmit, watch, setValue } = useForm();

    const handleRadioChange = (value) => {
        console.log(value);
        setView(value);
    };

    const handleInputChange = (event) => {
        setIsTokenUsed(false);
        setOrderSuccess(false);
    };

    const onSubmit = async (data) => {
        setIsSubmitting(true);
        const newUrl = data.url.trim();

        const tokenMatch = newUrl.match(/payments\/([a-zA-Z0-9]+)\//);
        if (tokenMatch) {
            const urlToken = tokenMatch[1];

            try {
                const response = await fetch("http://localhost:3000/api/url/check-url-token", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                    },
                    body: JSON.stringify({ url: newUrl, url_token: urlToken }),
                });

                const responseData = await response.json();
                if (response.status === 200 || response.status === 201) {
                    if (responseData.message) {
                        toast.success(responseData.message);
                        setIsTokenUsed(true);
                        setIsSubmitting(true);
                        const orderResponse = await fetch("http://localhost:3000/api/orders", {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json",
                            },
                            body: JSON.stringify({
                                url: newUrl,
                                user_name: "testuser",
                                ip: "192.168.1.1"
                            }),
                        });
                    
                        if (orderResponse.status === 200) {
                            setOrderSuccess(true);
                            toast.success("Order successful");
                        }

                        if (orderResponse.status === 500) {
                            toast.error("Order Failed");
                        }
                    }
                } else {
                    if (response.status === 500 && responseData.details) {
                        toast.error(responseData.details);
                        setIsTokenUsed(true);
                    } else {
                        toast.error('An error occurred while validating the URL.');
                    }
                }
            } catch (error) {
                toast.error("Error checking URL");
            }
        }
        setIsSubmitting(false);
    };

    const url = watch("url");

    useEffect(() => {
        const handler = setTimeout(() => {
            setValue("url", url);
        }, 1000);

        return () => {
            clearTimeout(handler);
        };
    }, [url, setValue]);

    return (
        <>
            <div className="flex items-center justify-center min-h-screen bg-gray-100">
                <Card className="w-96 flex flex-col items-center p-6 bg-white rounded-lg shadow-md">
                    <CardTitle className="text-xl font-bold text-primary mb-3">Payment</CardTitle>
                    <CardContent>
                        <RadioGroup defaultValue="scan" className="grid grid-cols-3 gap-4" onValueChange={handleRadioChange}>
                            <div>
                                <RadioGroupItem value="scan" id="scan" className="peer sr-only" />
                                <Label
                                    htmlFor="scan"
                                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                                >
                                    <img src={qr} className="mb-3 h-6 w-6"></img>
                                    Scan
                                </Label>
                            </div>
                            <div>
                                <RadioGroupItem
                                    value="crypto"
                                    id="crypto"
                                    className="peer sr-only"
                                />
                                <Label
                                    htmlFor="crypto"
                                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                                >
                                    <img src={crypto} className="mb-3 h-6 w-6"></img>
                                    Crypto
                                </Label>
                            </div>
                            <div>
                                <RadioGroupItem value="redeem" id="redeem" className="peer sr-only" />
                                <Label
                                    htmlFor="redeem"
                                    className="flex flex-col items-center justify-between rounded-md border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary"
                                >
                                    <img src={redeem} className="mb-3 h-6 w-6"></img>
                                    Redeem
                                </Label>
                            </div>
                        </RadioGroup>
                        <div className="mt-5">
                            {view === 'scan' && <QRCarousel />}
                            {view === 'crypto' && <CryptoPayment />}
                            {view === 'redeem' && <RedeemPayment />}
                        </div>

                        {view === 'scan' && (
                            <div className="flex justify-center items-center">
                                <Button
                                    className="sm:hidden rounded-full flex items-center"
                                    onClick={() => window.location.href = 'cashapp://'}
                                >
                                    <DollarSign className="mr-2 w-4 h-4 text-green-500 font-bold" />
                                    Pay with Cash App Pay
                                </Button>
                            </div>
                        )}

                    </CardContent>
                    {view === 'scan' && (
                        <form onSubmit={handleSubmit(onSubmit)} className="w-full">
                            <Input
                                type="text"
                                className="mt-2 p-2 border border-border rounded w-full"
                                placeholder="Enter your URL"
                                {...register("url", {
                                    validate: (value) => {
                                        if (!value) return true;
                                        if (value.length < 8) {
                                            return false;
                                        }
                                        if (!value.startsWith("https://cash.app/payments/")) {
                                            return false;
                                        }
                                        return true;
                                    },
                                    onChange: handleInputChange
                                })}
                            />
                            <Button type="submit" className="w-full mt-4 bg-accent bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-800 hover:text-white" disabled={isSubmitting || isTokenUsed || orderSuccess}>
                                {orderSuccess ? "Order Successful" : isSubmitting ? "Finalizing..." : "Finalize Order"}
                            </Button>
                        </form>
                    )}
                </Card>
            </div>
        </>
    );
};

export default Payment;