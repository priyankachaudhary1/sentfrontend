import { useCallback, useEffect, useState } from 'react';
import axios from "axios";
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { toast } from 'react-hot-toast';
import { setUserAuth } from '../../redux/userSlice';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useForm } from 'react-hook-form';
import {
    Card,
    CardContent,
} from "@/components/ui/card"

const Userpanel = () => {
    const [ipAddress, setIpAddress] = useState('');
    const [isUserNotFound, setIsUserNotFound] = useState(false);
    const [isIpBlocked, setIsIpBlocked] = useState(false);

    const dispatch = useDispatch();
    const navigate = useNavigate();

    const { register, handleSubmit, formState: { errors }, watch } = useForm();

    const BASE_URL = 'http://localhost:3000';

    const checkIpBlocked = useCallback(async (ip) => {
        try {
            const response = await axios.post(`${BASE_URL}/api/ips/check`, { ip_address: ip });
            if (response.data.blocked) {
                setIsIpBlocked(true);
                toast.error('IP address is blocked.');
            } else {
                setIsIpBlocked(false);
            }
        } catch (error) {
            console.log('Error checking IP block status');
        }
    }, []);

    const fetchIP = async () => {
        try {
            const response = await axios('https://api.ipify.org');
            const ip = response.data;
            setIpAddress(ip);
            checkIpBlocked(ip);
        } catch (error) {
            console.log('Error caught');
        }
    };

    useEffect(() => {
        fetchIP();
    }, []);

    const handleInputChange = (event) => {
        setIsUserNotFound(false);
    };

    const onSubmit = async (data) => {
        if (isIpBlocked) {
            toast.error('Cannot proceed, IP address is blocked.');
            return;
        }

        try {
            const response = await axios.post(`${BASE_URL}/api/users/check`, { user_name: data.userName, user_ipaddress: ipAddress });

            if (response.status === 200) {
                sessionStorage.setItem('check', data.userName);
                dispatch(setUserAuth({ username: data.userName, ipAddress, userID: response.data.data.user_id }));
                navigate('/payment');
                toast.success('User Validated');
                setIsUserNotFound(false);
            }
        } catch (error) {
            toast.error(error.response.data.message);
            setIsUserNotFound(true);
        }
    }

    const userNameValue = watch('userName');

    useEffect(() => {
        if (userNameValue) {
            setIsUserNotFound(false);
        }
    }, [userNameValue]);

    return (
        <div className="flex items-center justify-center min-h-screen">
            <Card className="w-full max-w-md p-6 bg-white rounded-lg shadow-md">
                <CardContent className="flex flex-col items-center">
                    <Label className="mb-2 text-lg text-white">Username</Label>
                    <form onSubmit={handleSubmit(onSubmit)} className="w-full">
                        <Input
                            className="mb-4 w-full p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-center"
                            type='text'
                            placeholder='Enter your username'
                            {...register('userName', { required: 'Username is required' })}
                            onChange={handleInputChange}
                        />
                        <Button 
                            className="w-full py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition duration-300" 
                            type="submit"
                            disabled={isUserNotFound}
                        >
                            Place Order
                        </Button>
                    </form>
                </CardContent>
            </Card>
        </div>
    );
}

export default Userpanel;