import { Outlet, Navigate } from 'react-router-dom';
import { useEffect, useState } from "react";
import { useSelector, useDispatch } from 'react-redux';
import { setLoginUser } from '../redux/userSlice';

const PrivateRoute = () => {
    const userAuth = useSelector((state) => state.user.userAuth);
    const dispatch = useDispatch();
    const [isVerified, setIsVerified] = useState(null);

    useEffect(() => {
        const verifyUser = async () => {
            try {
                const verifiedUser = sessionStorage.getItem('check');
                if (verifiedUser && userAuth.username) {
                    if (verifiedUser === userAuth.username) {
                        setIsVerified(true);
                    } else {
                        sessionStorage.clear('check');
                        throw new Error('User does not match');
                    }
                } else {
                    setIsVerified(false);
                    throw new Error('User does not match');
                }
            } catch (error) {
                setIsVerified(false);
            }
        };

        verifyUser();
    }, [userAuth]);

    if (isVerified === null) {
        return <div>Loading...</div>;
    }

    return (
        <div>
            {isVerified ? <Outlet /> : <Navigate to='/' />}
        </div>
    );
}

export default PrivateRoute;