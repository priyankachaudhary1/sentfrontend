import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  userAuth: {
    username: "",
    ipAddress: "",
    userID: ""
  },
  loginUser: null
};

const userSlice = createSlice({
  name: 'user',
  initialState,
  reducers: {
    setUserAuth: (state, action) => {
      state.userAuth = action.payload;
    },
    setLoginUser: (state, action) => {
      state.loginUser = action.payload;
    }
  }
});

export const { setUserAuth, setLoginUser } = userSlice.actions;
export default userSlice.reducer;