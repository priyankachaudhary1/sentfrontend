// import { Children, useState } from "react";
// import Usercontext from "./Usercontext";

// export default function UserContextProvider({ children }) {
//     const [userAuth, setUserAuth] = useState({
//         username: "",
//         ipAddress: "",
//         userID: ""
//     });
    
//     const [loginUser, setLoginUser] = useState(null);

//     return (
//         <Usercontext.Provider value={{ userAuth, setUserAuth, loginUser, setLoginUser }}>{children}</Usercontext.Provider>
//     )
// }