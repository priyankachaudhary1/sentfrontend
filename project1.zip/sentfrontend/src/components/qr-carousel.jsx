import { Card, CardContent } from "@/components/ui/card";
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel";
import { BACKEND_ENDPOINT } from "@/config";
import { useCallback, useEffect, useState } from "react";

const QRCarousel = () => {
  const [api, setApi] = useState(null);
  const [current, setCurrent] = useState(0);
  const [images, setImages] = useState([]);

  const fetchImages = useCallback(async () => {
    try {
      const response = await fetch(`${BACKEND_ENDPOINT}/api/tags/generate-urls`);
      const data = await response.json();

      if (Array.isArray(data.data)) {
        setImages(data.data);
      } else {
        console.error("API response is not an array:", data);
      }
    } catch (error) {
      console.error("Error fetching images:", error);
    }
  }, []);

  useEffect(() => {
    fetchImages();
  }, [fetchImages]);
  useEffect(() => {
    if (!api) {
      return;
    }

    setCurrent(api.selectedScrollSnap());

    api.on("select", () => {
      setCurrent(api.selectedScrollSnap());
    });
  }, [api]);

  return (
    <div>
      <Carousel setApi={setApi} className="w-full max-w-xs">
        <CarouselContent>
          {images.map((image, index) => (
            <CarouselItem key={index}>
              <Card>
                <CardContent className="flex aspect-square items-center justify-center p-6">
                  <img src={image?.url} alt={image?.name} className="w-full h-full object-cover" />
                </CardContent>
              </Card>
            </CarouselItem>
          ))}
        </CarouselContent>
        <CarouselPrevious />
        <CarouselNext />
      </Carousel>
      <div className="py-2 text-center">
        <div className="text-xl text-black font-bold">
          {images[current] ? `${images[current]?.tag_identifier}` : "No Image"}
        </div>
        <div className="text-sm text-green-600 font-bold">
          {images[current] ? images[current]?.name : "No Image"}
        </div>
      </div>
    </div>
  );
};

export default QRCarousel;