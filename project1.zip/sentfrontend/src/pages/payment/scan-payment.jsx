import { useState } from "react";
import { useSelector } from 'react-redux';
import axios from "axios";
import { toast } from 'react-hot-toast';
import scan from "/scan.jpg";
import qr from "../../assets/qr.png";

const ScanPayment = ({ propsId }) => {
    const [url, setUrl] = useState("");
    const [isActive, setIsActive] = useState(false);
    const [isCorrect, setIsCorrect] = useState();
    const [color, setColor] = useState('');

    const userAuth = useSelector((state) => state.user.userAuth);

    const handlesubmiturl = async (e) => {
        e.preventDefault();
        console.log('hitted');

        console.log({
            url: url,
            ip: userAuth.ipAddress,
            user_name: userAuth.userName
        });

        try {
            const response = await axios.post(`${BACKEND_ENDPOINT}/api/orders/`, {
                url: url,
                ip: userAuth.ipAddress,
                user_name: userAuth.userName
            });
            if (response.status === 200) {
                console.log('Successfully transaction of the url');
                toast.success('Success');
            } else {
                throw new Error('Error caught in transaction of url');
            }
        } catch (error) {
            console.log(error);
            toast.error(error.response.data.message);
        }
    };

    const handleInputResponse = (input) => {
        setUrl(input);
        if (!input.includes('cash.app/payments')) {
            setIsCorrect(false);
            setColor('red');
        } else {
            setIsCorrect(true);
            setColor('green');
        }
    };

    return (
        <div>
            <form onSubmit={handlesubmiturl} className="scanpayform">
                <div className="scanpay">
                    <img src={scan} alt="scan picture" />
                </div>
                <br></br>
                <span className="clickpay">CLICK TO PAY</span>

                <h4>Payment Address</h4>
                <h4>LTCXXX123</h4>
                <br></br>

                <label className="label">Paste your url (Mandatory)</label>
                <br></br>
                <br></br>

                <input onChange={e => handleInputResponse(e.target.value)} value={url} />
                <br></br>

                {color === "" ? null : color === 'green' ? <span style={{ color: 'green' }}>Valid URL</span> : <span style={{ color: 'red' }}>Invalid URL</span>}

                <br></br>
                <button className="btnPay">Finalize Order</button>
            </form>

            {isActive && <div style={{ background: 'orangered', width: '600px', height: '320px', top: '10rem', position: 'absolute' }}>
                <div style={{ textAlign: 'right', marginRight: '2rem', marginTop: '1rem' }}>
                    <span style={{ textAlign: 'right' }} onClick={() => setIsActive(false)}>&#10539;</span>
                </div>

                <h3>Successfull transaction</h3>

                <p>This link will be validate only for 15 min.</p>
                <br></br>
            </div>}
        </div>
    );
};

export default ScanPayment;